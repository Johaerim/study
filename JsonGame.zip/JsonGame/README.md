# ClassExample2DGameMergedProject
Merged Unity Project in 2D Game Programming Class


### Figures
* 실행화면

    <img src="Docs/fig0.png" style="width:420px"></img><br>
    <img src="Docs/fig1.png" style="width:420px"></img><br>
    <img src="Docs/fig2.png" style="width:420px"></img><br>
    <img src="Docs/fig3.png" style="width:420px"></img><br>

### Contributor
기획 by 여랑<br>
코드 by 영훈<br>

