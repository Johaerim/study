using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;
using System.IO;

public class NewtonsoftJsonOwl : MonoBehaviour
{
    public JsonDataClass jsonData;
    // Start is called before the first frame update
    void Start()
    {
        jsonData = new JsonDataClass();
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    [System.Serializable]
    public class JsonDataClass
    {
        public int Score;
        public double doubleNum;

        public string Player;


        public JsonDataClass()
        {
            Score = 40;
            doubleNum = 123.4556;
            Player = "조해림 Owl";
        }

        public void PrintData()
        {
            Debug.Log($"integer = {Score}");
            Debug.Log($"double = {doubleNum}");
            Debug.Log($"str = {Player}");
        }

        
    }

    public void WriteToJsonFile() 
    {
        string savingObjectToJson = JsonConvert.SerializeObject(jsonData);
        string savingJsonFileName = Path.Combine(Application.dataPath, "ObjectToJson.json");
        File.WriteAllText(savingJsonFileName, savingObjectToJson);
    }

    public void ReadFromJsonFile() 
    {
        string jsonFileName = Path.Combine(Application.dataPath, "ObjectToJson.json");
        string readJsonData = File.ReadAllText(jsonFileName);
        JsonDataClass createObjectFromJson = JsonConvert.DeserializeObject<JsonDataClass>(readJsonData);
        createObjectFromJson.PrintData();
    }
}
